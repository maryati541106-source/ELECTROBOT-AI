const notes={
"Bekalan elektrik":"Bekalan elektrik ialah sumber tenaga yang membekalkan voltan kepada litar. Dalam pembelajaran asas, murid perlu membezakan bekalan satu fasa dan tiga fasa serta memahami hubungan voltan, arus dan kuasa.",
"Simbol elektrik":"Simbol elektrik digunakan untuk mewakili komponen dalam lukisan litar. Biasakan diri dengan simbol lampu, suis, soket, MCB, RCCB, motor dan bumi.",
"MCB dan RCCB":"MCB melindungi litar daripada arus berlebihan dan litar pintas. RCCB pula mengesan ketidakimbangan/kebocoran arus dan membantu mengurangkan risiko renjatan elektrik.",
"Motor elektrik":"Motor menukar tenaga elektrik kepada tenaga mekanikal. Dalam amali, semak bekalan, sambungan kawalan, contactor dan overload relay mengikut prosedur yang ditetapkan.",
"Pendawaian domestik":"Pendawaian domestik melibatkan susunan dan sambungan peralatan elektrik seperti lampu dan soket. Kerja sebenar hendaklah dibuat mengikut piawaian dan prosedur keselamatan.",
"Keselamatan bengkel":"Utamakan PPE, pengasingan bekalan, pemeriksaan alat, kawasan kerja yang kemas dan arahan guru. Jangan menyentuh konduktor hidup atau membuat kerja pendawaian tanpa kebenaran dan kompetensi."
};
function showInfo(k){document.getElementById('modalTitle').textContent=k;document.getElementById('modalText').textContent=notes[k]||"Nota pembelajaran akan ditambah.";document.getElementById('modal').classList.add('show')}
function hideModal(){document.getElementById('modal').classList.remove('show')}
function closeModal(e){if(e.target.id==='modal')hideModal()}
function toggleMenu(){document.getElementById('nav').classList.toggle('open')}

function diagnose(){
 const p=document.getElementById('problem').value.toLowerCase();
 let a="Sila perincikan simptom. Sebagai panduan pembelajaran, semak bekalan, sambungan, komponen kawalan dan perlindungan secara sistematik.";
 if(p.includes("motor")||p.includes("berpusing")) a="Jika motor tidak berpusing: 1) semak bekalan, 2) semak fius/MCB, 3) semak contactor dan litar kawalan, 4) semak overload relay, 5) semak sambungan motor. Pastikan bekalan diasingkan sebelum pemeriksaan fizikal.";
 else if(p.includes("lampu")||p.includes("tidak menyala")) a="Jika lampu tidak menyala: semak bekalan, MCB, suis, sambungan neutral/fasa dan keadaan lampu. Untuk litar kawalan, semak terminal berkaitan. Jangan bekerja pada litar hidup.";
 else if(p.includes("rccb")) a="Jika RCCB kerap trip, kemungkinan terdapat kebocoran arus atau masalah penebatan. Asingkan beban secara selamat dan dapatkan pemeriksaan oleh orang kompeten.";
 else if(p.includes("mcb")||p.includes("trip")) a="Jika MCB trip, semak sama ada berlaku beban berlebihan atau litar pintas. Jangan paksa MCB ON berulang kali tanpa mengenal pasti punca.";
 document.getElementById('diagnosis').innerHTML="<b>ELECTROBOT AI:</b> "+a;
}

const questions=[
["Apakah fungsi MCB?",["Mengawal motor","Melindungi litar daripada arus berlebihan","Menyimpan tenaga","Menukar voltan"],1],
["Apakah fungsi RCCB?",["Mengesan kebocoran arus","Menghidupkan motor","Mengukur suhu","Menyimpan arus"],0],
["Peranti yang biasa digunakan untuk mengawal motor secara elektromekanikal ialah…",["Contactor","Mentol","Soket","Palam"],0],
["Overload relay digunakan untuk melindungi…",["Lampu sahaja","Motor daripada beban berlebihan","Wayar bumi","Suis"],1],
["Apakah langkah pertama sebelum kerja elektrik?",["Sentuh konduktor","Asingkan bekalan mengikut prosedur","Basahkan tangan","Buka semua suis"],1],
["Alat untuk mengukur voltan ialah…",["Multimeter","Playar","Pemutar skru","Penukul"],0],
["Simbol elektrik membantu kita membaca…",["Lukisan litar","Jadual waktu","Markah peperiksaan","Harga komponen"],0],
["Jika MCB kerap trip, tindakan yang sesuai ialah…",["Paksa ON berulang kali","Kenal pasti punca beban berlebihan/litar pintas","Tukar warna wayar","Abaikan"],1],
["PPE bermaksud…",["Personal Protective Equipment","Power Phase Electric","Public Protection Engine","Panel Power Equipment"],0],
["Apakah tujuan utama amalan keselamatan elektrik?",["Menyiapkan kerja lebih cepat","Mengurangkan risiko kemalangan dan kecederaan","Mengurangkan warna kabel","Menambah penggunaan tenaga"],1]
];
let qi=0,score=0,answered=false;
function loadQuestion(){
 answered=false;
 const q=questions[qi]; document.getElementById('qnum').textContent=`Soalan ${qi+1} / ${questions.length}`;document.getElementById('score').textContent=score;document.getElementById('question').textContent=q[0];
 const box=document.getElementById('options');box.innerHTML="";
 q[1].forEach((x,i)=>{const b=document.createElement('button');b.className="option";b.textContent=String.fromCharCode(65+i)+". "+x;b.onclick=()=>answer(i,b);box.appendChild(b)});
 document.getElementById('nextBtn').disabled=true;document.getElementById('nextBtn').textContent=qi===questions.length-1?"Lihat Keputusan →":"Soalan Seterusnya →";document.getElementById('quizResult').innerHTML="";
}
function answer(i,b){if(answered)return;answered=true;const q=questions[qi];document.querySelectorAll('.option').forEach((x,n)=>{if(n===q[2])x.classList.add('correct')});if(i===q[2])score++;else b.classList.add('wrong');document.getElementById('score').textContent=score;document.getElementById('nextBtn').disabled=false}
function nextQuestion(){if(qi<questions.length-1){qi++;loadQuestion()}else{document.getElementById('quizResult').innerHTML=`<div style="margin-top:18px;padding:16px;border-radius:12px;background:#eaf5ff"><b>🏆 Keputusan: ${score}/${questions.length}</b><br>${score>=8?"Tahniah! Penguasaan sangat baik.":"Teruskan latihan dan ulang semula nota."}</div>`;document.getElementById('nextBtn').disabled=true}}
loadQuestion();

const kb=[
["rccb","RCCB berfungsi mengesan kebocoran atau ketidakimbangan arus dan membantu melindungi pengguna daripada risiko renjatan elektrik."],
["mcb","MCB melindungi litar daripada arus berlebihan dan litar pintas dengan memutuskan bekalan apabila keadaan tidak normal dikesan."],
["motor","Jika motor tidak berpusing, semak bekalan, MCB, litar kawalan, contactor, overload relay dan sambungan mengikut prosedur keselamatan."],
["keselamatan","Utamakan pengasingan bekalan, PPE dan arahan guru/orang kompeten. Jangan bekerja pada litar hidup."],
["overload","Overload relay membantu melindungi motor apabila berlaku beban berlebihan untuk tempoh tertentu."]
];
function ask(t){document.getElementById('chatInput').value=t;sendMessage()}
function sendMessage(){const input=document.getElementById('chatInput');const text=input.value.trim();if(!text)return;addMsg(text,'user');input.value='';let answer="Saya boleh membantu dengan MCB, RCCB, motor, contactor, overload relay, pendawaian dan keselamatan. Cuba taip soalan yang lebih khusus.";const low=text.toLowerCase();for(const [key,val] of kb){if(low.includes(key)){answer=val;break}}setTimeout(()=>addMsg(answer,'bot'),250)}
function addMsg(text,type){const box=document.getElementById('chatMessages');const div=document.createElement('div');div.className="msg "+type;div.innerHTML=type==="bot"?`<b>ELECTROBOT AI 🤖</b><br>${text}`:text;box.appendChild(div);box.scrollTop=box.scrollHeight}
