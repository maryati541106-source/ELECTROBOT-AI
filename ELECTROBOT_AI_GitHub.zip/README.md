# ELECTROBOT AI 🤖

Prototype **TVET Electrical Learning Chatbot** berdasarkan reka bentuk poster ELECTROBOT AI.

## Fungsi
- Nota Elektrik
- Komponen Elektrik
- Troubleshooting AI
- Kuiz Kendiri 10 soalan
- Chat dengan ELECTROBOT AI
- Cabaran Mingguan
- Responsive untuk telefon, tablet dan komputer

## Robot asal
Imej `assets/electrobot-poster.png` digunakan **tepat daripada imej asal yang diberikan**, jadi reka bentuk robot tidak ditukar.

## Cara letak di GitHub
1. Buat repository baharu di GitHub, contohnya `electrobot-ai`.
2. Upload semua fail dan folder dalam projek ini.
3. Pastikan `index.html` berada di bahagian utama repository.
4. Buka **Settings → Pages**.
5. Pada **Build and deployment**, pilih **Deploy from a branch**.
6. Pilih branch `main` dan folder `/ (root)`.
7. Simpan. GitHub akan beri alamat laman web.

> Nota: Chat ini ialah chatbot demo berasaskan jawapan yang telah diprogramkan. Untuk AI sebenar yang boleh menjawab soalan bebas, sambungkan bahagian `sendMessage()` kepada API/backend yang selamat. Jangan letak API key rahsia terus dalam JavaScript GitHub Pages.
